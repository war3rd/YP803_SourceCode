//
//  HelloHTTPGetASyncAppDelegate.h
//  HelloHTTPGetASync
//
//  Created by Liu Kent on 2011/4/5.
//  Copyright 2011年 SoftArt Laboratory. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HelloHTTPGetASyncViewController;

@interface HelloHTTPGetASyncAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet HelloHTTPGetASyncViewController *viewController;

@end
