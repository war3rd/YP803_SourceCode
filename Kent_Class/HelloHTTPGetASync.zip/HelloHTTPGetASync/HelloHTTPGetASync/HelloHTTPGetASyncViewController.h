//
//  HelloHTTPGetASyncViewController.h
//  HelloHTTPGetASync
//
//  Created by Liu Kent on 2011/4/5.
//  Copyright 2011年 SoftArt Laboratory. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MyUIImageView.h"

@interface HelloHTTPGetASyncViewController : UIViewController {
    MyUIImageView *myImageView1;
    MyUIImageView *myImageView2;    
}

@end
