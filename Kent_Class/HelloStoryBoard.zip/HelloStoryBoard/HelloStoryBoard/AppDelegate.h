//
//  AppDelegate.h
//  HelloStoryBoard
//
//  Created by BigkongWang on 2014/9/25.
//  Copyright (c) 2014年 Max. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

