//
//  CustomizedTableViewCell.m
//  HelloStoryBoard
//
//  Created by richman on 2014/10/6.
//  Copyright (c) 2014年 Max. All rights reserved.
//

#import "CustomizedTableViewCell.h"

@implementation CustomizedTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)theSwitch:(id)sender {
}
@end
