//
//  MyCustomizedCellTableViewController.h
//  HelloStoryBoard
//
//  Created by richman on 2014/10/6.
//  Copyright (c) 2014年 Max. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyCustomizedCellTableViewController : UITableViewController

@end
