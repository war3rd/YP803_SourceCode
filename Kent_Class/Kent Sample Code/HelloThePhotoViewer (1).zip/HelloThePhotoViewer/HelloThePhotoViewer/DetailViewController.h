//
//  DetailViewController.h
//  HelloThePhotoViewer
//
//  Created by Kent Liu on 2014/4/27.
//  Copyright (c) 2014年 Kent Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController <UIScrollViewDelegate>

@property (strong, nonatomic) id detailItem;

@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel;

@property (strong,nonatomic) NSNumber *targetIndex;
@property (strong,nonatomic) NSArray *datas;
@property (weak, nonatomic) IBOutlet UIScrollView *theScrollView;
@property (weak, nonatomic) IBOutlet UIImageView *theImageView;
- (IBAction)playStopButtonPressed:(id)sender;
@property (weak, nonatomic) IBOutlet UISlider *timeIntervalSlider;

@end
