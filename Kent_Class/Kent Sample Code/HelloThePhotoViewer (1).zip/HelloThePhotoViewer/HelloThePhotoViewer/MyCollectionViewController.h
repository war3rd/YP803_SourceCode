//
//  MyCollectionViewController.h
//  HelloThePhotoViewer
//
//  Created by Kent Liu on 2014/4/27.
//  Copyright (c) 2014年 Kent Liu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UICollectionView+Draggable.h"
#import "DraggableCollectionViewFlowLayout.h"

@interface MyCollectionViewController : UICollectionViewController <UICollectionViewDataSource_Draggable>

@end
