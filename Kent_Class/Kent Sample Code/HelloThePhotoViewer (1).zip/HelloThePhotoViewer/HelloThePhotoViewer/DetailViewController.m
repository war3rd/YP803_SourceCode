//
//  DetailViewController.m
//  HelloThePhotoViewer
//
//  Created by Kent Liu on 2014/4/27.
//  Copyright (c) 2014年 Kent Liu. All rights reserved.
//

#import "DetailViewController.h"
#import <QuartzCore/QuartzCore.h>

@interface DetailViewController ()
{
    BOOL isPlaying;
}
- (void)configureView;
@end

@implementation DetailViewController

#pragma mark - Managing the detail item

- (void)setTargetIndex:(NSNumber *)newTargetIndex
{
    if (_targetIndex != newTargetIndex) {
        _targetIndex = newTargetIndex;
        
        // Update the view.
        [self configureView];
    }
}

- (void)configureView
{
    // Update the user interface for the detail item.

    UIImage *targetImage=[UIImage imageNamed:_datas[_targetIndex.integerValue]];
    
    _theImageView.image=targetImage;
    _theImageView.contentMode=UIViewContentModeScaleAspectFit;
    
    _theScrollView.contentSize=targetImage.size;
    
    _theScrollView.maximumZoomScale=5.0;
    _theScrollView.minimumZoomScale=1.0;
    _theScrollView.zoomScale=1.0;
    
}

- (UIView*) viewForZoomingInScrollView:(UIScrollView *)scrollView {
    
    return _theImageView;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    [self configureView];
    
    self.automaticallyAdjustsScrollViewInsets=NO;
    
    // Add Gesture Recognizers
    
    UISwipeGestureRecognizer *toLeft=[[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(toLeft)];
    toLeft.direction=UISwipeGestureRecognizerDirectionLeft;
    
    [_theImageView addGestureRecognizer:toLeft];
    
    UISwipeGestureRecognizer *toRight=[[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(toRight)];
    toRight.direction=UISwipeGestureRecognizerDirectionRight;
    
    [_theImageView addGestureRecognizer:toRight];
    
    // Hide Slider
    
    [_timeIntervalSlider setHidden:YES];
    
    // Add Double Tap Gesture Recognizer
    UITapGestureRecognizer *doubleTap=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(zoomSwitch)];
    doubleTap.numberOfTapsRequired=2;
    [_theImageView addGestureRecognizer:doubleTap];
    
}

- (void) zoomSwitch {
    
    if(_theScrollView.zoomScale==1.0)
    {
        _theScrollView.zoomScale=3.0;
    }
    else
    {
        _theScrollView.zoomScale=1.0;
    }
    
}

- (void) toLeft {
    NSInteger currentIndex=_targetIndex.integerValue;
    currentIndex++;
    if(currentIndex>=_datas.count)
        currentIndex=0;
    
    _targetIndex=[NSNumber numberWithInteger:currentIndex];
    
    // Add Animation
    CATransition *transition=[CATransition animation];
    transition.duration=0.4;
    transition.timingFunction=[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
    transition.type=kCATransitionReveal;
    transition.subtype=kCATransitionFromRight;
    
    [self configureView];
    
    [_theImageView.layer addAnimation:transition forKey:nil];
    
    // Prepare next Slide Show
    
    if(isPlaying)
    {
        NSLog(@"Prepare next play. (%@)",[self description]);
        [self performSelector:@selector(toLeft) withObject:nil afterDelay:_timeIntervalSlider.value];
    }
    
}

- (void) toRight {
    NSInteger currentIndex=_targetIndex.integerValue;
    currentIndex--;
    
    if(currentIndex<0)
        currentIndex=_datas.count-1;
    
    _targetIndex=[NSNumber numberWithInteger:currentIndex];
    
    // Add Animation
    CATransition *transition=[CATransition animation];
    transition.duration=0.4;
    transition.timingFunction=[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
    transition.type=kCATransitionReveal;
    transition.subtype=kCATransitionFromLeft;
    
    [self configureView];
    
    [_theImageView.layer addAnimation:transition forKey:nil];
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)playStopButtonPressed:(id)sender {
    
    if(isPlaying==NO)
    {
        UIBarButtonItem *stopButton=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemStop target:self action:@selector(playStopButtonPressed:)];
        self.navigationItem.rightBarButtonItem=stopButton;
        isPlaying=YES;
        
        // Start Slide Show
        [_timeIntervalSlider setHidden:NO];
        [self performSelector:@selector(toLeft) withObject:nil afterDelay:_timeIntervalSlider.value];
    }
    else
    {
        UIBarButtonItem *playButton=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemPlay target:self action:@selector(playStopButtonPressed:)];
        self.navigationItem.rightBarButtonItem=playButton;
        isPlaying=NO;
        
        // Stop Slide Show
        [_timeIntervalSlider setHidden:YES];
        [NSObject cancelPreviousPerformRequestsWithTarget:self];
    }
}

- (void) viewDidDisappear:(BOOL)animated {
    
    [super viewDidDisappear:animated];
    
    NSLog(@"viewDidDisappear.");
    
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
}

- (void) dealloc {
    
    NSLog(@"dealloc.");
    
}

@end
