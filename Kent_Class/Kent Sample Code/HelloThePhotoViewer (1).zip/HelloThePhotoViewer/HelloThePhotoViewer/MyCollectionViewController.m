//
//  MyCollectionViewController.m
//  HelloThePhotoViewer
//
//  Created by Kent Liu on 2014/4/27.
//  Copyright (c) 2014年 Kent Liu. All rights reserved.
//

#import "MyCollectionViewController.h"
#import "MyCollectionViewCell.h"
#import "DraggableCircleLayout.h"

@interface MyCollectionViewController ()
{
    NSMutableArray *datas;
}

@end

@implementation MyCollectionViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    datas=[NSMutableArray arrayWithArray:@[@"cat1.jpg",@"cat2.jpg",@"cat3.jpg",@"cat4.jpg",@"cat5.jpg",@"cat6.jpg",@"cat7.jpg",@"cat8.jpg",@"cat9.jpg",@"cat10.jpg"]];
    
    // Prepare Draggable Support
    self.collectionView.draggable=YES;

#if 1
    DraggableCollectionViewFlowLayout *layout=[DraggableCollectionViewFlowLayout new];
    layout.scrollDirection=UICollectionViewScrollDirectionVertical;
    [layout setItemSize:CGSizeMake(152, 140)];
#else
    
    DraggableCircleLayout *layout = [DraggableCircleLayout new];
    [layout setItemSize:CGSizeMake(144, 133)];
#endif
    
    self.collectionView.collectionViewLayout=layout;
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger) numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    
    return 1;
}

- (NSInteger) collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    return datas.count;
}

- (UICollectionViewCell*) collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    MyCollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:@"MyCollectionViewCell" forIndexPath:indexPath];
    
    cell.theImageView.image=[UIImage imageNamed:datas[indexPath.row]];
    cell.theLabel.text=datas[indexPath.row];
//    cell.tag=indexPath.row;
    
    return cell;
}

-(BOOL) collectionView:(UICollectionView *)collectionView canMoveItemAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}

- (void) collectionView:(UICollectionView *)collectionView moveItemAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
    
    id item=datas[fromIndexPath.row];
    [datas removeObjectAtIndex:fromIndexPath.row];
    [datas insertObject:item atIndex:toIndexPath.row];
    
    NSArray *cells=collectionView.subviews;
    
    NSLog(@"%@",[cells description]);
    
}



#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    
    id viewController=segue.destinationViewController;
    
    NSArray *selectedItems=self.collectionView.indexPathsForSelectedItems;
    NSIndexPath *indexPath=selectedItems[0];
    NSInteger targetIndex=indexPath.row;
    
    [viewController setValue:datas forKey:@"datas"];
    [viewController setValue:[NSNumber numberWithInteger:targetIndex]
                      forKey:@"targetIndex"];
    
}


@end
