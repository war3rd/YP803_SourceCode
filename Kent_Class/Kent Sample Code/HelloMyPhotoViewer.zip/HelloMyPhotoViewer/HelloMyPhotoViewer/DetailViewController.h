//
//  DetailViewController.h
//  HelloMyPhotoViewer
//
//  Created by Liu Kent on 12/2/19.
//  Copyright (c) 2012年 SoftArt Laboratory. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController <UIScrollViewDelegate>

@property (strong, nonatomic) id detailItem;

@property (strong, nonatomic) IBOutlet UILabel *detailDescriptionLabel;

@property (weak, nonatomic) IBOutlet UIScrollView *theScrollView;

@property (weak,nonatomic) IBOutlet UIImageView *theImageView;
@property (assign,nonatomic) NSInteger nCurrentIndex;
@property (strong,nonatomic) NSMutableArray *dataArray;
@property (assign,nonatomic) Boolean bSlideShow;
@property (weak, nonatomic) IBOutlet UISlider *slideShowTimeIntervalSlider;


@end
