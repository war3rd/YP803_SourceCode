//
//  PhotoTableViewCell.m
//  HelloMyPhotoViewer
//
//  Created by Liu Kent on 12/2/19.
//  Copyright (c) 2012年 SoftArt Laboratory. All rights reserved.
//

#import "PhotoTableViewCell.h"

@implementation PhotoTableViewCell
@synthesize theButton1,theButton2,theButton3;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
