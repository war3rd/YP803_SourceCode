//
//  MasterViewController.m
//  HelloMyPhotoViewer
//
//  Created by Liu Kent on 12/2/19.
//  Copyright (c) 2012年 SoftArt Laboratory. All rights reserved.
//

#import "MasterViewController.h"

#import "PhotoTableViewCell.h"

#import "DetailViewController.h"

@implementation MasterViewController
@synthesize dataArray;


- (void)awakeFromNib
{
    [super awakeFromNib];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    self.dataArray=[NSMutableArray arrayWithObjects:
                    @"cat1.jpg",@"cat2.jpg",@"cat3.jpg",
                    @"cat4.jpg",@"cat5.jpg",@"cat6.jpg",
                    @"cat7.jpg",@"cat8.jpg",@"cat9.jpg",
                    @"cat10.jpg", nil];
    
    UIBarButtonItem *slideShowButton=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemPlay target:self action:@selector(startSlideShow)];
    
    self.navigationItem.rightBarButtonItem=slideShowButton;
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    NSInteger nResult=[self.dataArray count]/3;
    
    if([self.dataArray count]%3!=0)
        nResult++;
    
    return nResult;
}

- (UITableViewCell*) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *cellIdentifirt=@"PhotoTableViewCell";
    
    PhotoTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:cellIdentifirt];
    
    if(cell==nil)
    {
        cell=[[PhotoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifirt];
    }
    
    // Config the cell
    NSInteger nTotalCount=[self.dataArray count];
    NSInteger nStartIndex=3*[indexPath row];
    
    // Button1
    if(nStartIndex<nTotalCount)
    {
        cell.theButton1.tag=nStartIndex;
        UIImage *image=[UIImage imageNamed:[self.dataArray objectAtIndex:nStartIndex]];
        [cell.theButton1 setImage:image forState:UIControlStateNormal];
        [cell.theButton1 addTarget:self action:@selector(photoButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
        [cell.theButton1 setHidden:NO];
    }
    else 
    {
         [cell.theButton1 setHidden:YES];
    }
    
    // Button2
    nStartIndex++;
    if(nStartIndex<nTotalCount)
    {
        cell.theButton2.tag=nStartIndex;
        UIImage *image=[UIImage imageNamed:[self.dataArray objectAtIndex:nStartIndex]];
        [cell.theButton2 setImage:image forState:UIControlStateNormal];
        [cell.theButton2 addTarget:self action:@selector(photoButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
        [cell.theButton2 setHidden:NO];
    }
    else 
    {
        [cell.theButton2 setHidden:YES];
    }    
    
    // Button3
    nStartIndex++;
    if(nStartIndex<nTotalCount)
    {
        cell.theButton3.tag=nStartIndex;
        UIImage *image=[UIImage imageNamed:[self.dataArray objectAtIndex:nStartIndex]];
        [cell.theButton3 setImage:image forState:UIControlStateNormal];
        [cell.theButton3 addTarget:self action:@selector(photoButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
        [cell.theButton3 setHidden:NO];
    }
    else 
    {
        [cell.theButton3 setHidden:YES];
    }      
    
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    return cell;
}

- (void) photoButtonPressed:(id)sender {
    
    [self performSegueWithIdentifier:@"showPhoto" sender:sender];
    
}

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    DetailViewController *viewController=segue.destinationViewController;
    UIButton *theButton=(UIButton*)sender;
    
    if(theButton!=nil)
    {
        viewController.bSlideShow=NO;
        viewController.nCurrentIndex=theButton.tag;
        viewController.dataArray=self.dataArray;
    }
    else
    {
        viewController.bSlideShow=YES;
        viewController.nCurrentIndex=0;
        viewController.dataArray=self.dataArray;        
    }
    
}

- (void) startSlideShow {
    
    [self performSegueWithIdentifier:@"showPhoto" sender:nil]; 
    
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source.
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

@end
