//
//  DetailViewController.m
//  HelloMyPhotoViewer
//
//  Created by Liu Kent on 12/2/19.
//  Copyright (c) 2012年 SoftArt Laboratory. All rights reserved.
//

#import "DetailViewController.h"
#import <QuartzCore/QuartzCore.h>

@interface DetailViewController ()

@property (strong,nonatomic) NSTimer *timerForChangePhotos;    
@property (assign,nonatomic) CFTimeInterval lastPhotoUpdateTime;
@property (assign,nonatomic) CFTimeInterval slideShowTimeInterval;

- (void)configureView;
@end

@implementation DetailViewController

@synthesize detailItem = _detailItem;
@synthesize detailDescriptionLabel = _detailDescriptionLabel;
@synthesize theScrollView = _theScrollView;
@synthesize theImageView,nCurrentIndex,dataArray;
@synthesize timerForChangePhotos,lastPhotoUpdateTime,slideShowTimeInterval;
@synthesize bSlideShow;
@synthesize slideShowTimeIntervalSlider;

#pragma mark - Managing the detail item

- (void)setDetailItem:(id)newDetailItem
{
    if (_detailItem != newDetailItem) {
        _detailItem = newDetailItem;
        
        // Update the view.
        [self configureView];
    }
}

- (void)configureView
{
    // Update the user interface for the detail item.

    if (self.detailItem) {
        self.detailDescriptionLabel.text = [self.detailItem description];
    }
    
    UIImage *image=[UIImage imageNamed:[self.dataArray objectAtIndex:self.nCurrentIndex]];
    
    CGSize imageSize=image.size;
    [self.theImageView setImage:image];
    
    self.theImageView.contentMode=UIViewContentModeScaleAspectFit;

    self.theScrollView.contentSize=imageSize;
    
    self.theScrollView.maximumZoomScale=3;
    self.theScrollView.minimumZoomScale=1;
    self.theScrollView.zoomScale=1;
    

     
    
    
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    [self configureView];
    
    if (bSlideShow) {
        // Prepare Timer
        
        timerForChangePhotos = [NSTimer scheduledTimerWithTimeInterval: 1.0
                                                                target: self
                                                              selector: @selector(handleTimer:)
                                                              userInfo: nil
                                                               repeats: YES];	
        
        
        
        slideShowTimeInterval=1.0;
        
        [slideShowTimeIntervalSlider setHidden:NO];
        
    }
    else
    {    
        // Add Gestures
        UISwipeGestureRecognizer *rightGesture=[[UISwipeGestureRecognizer alloc] init];
        rightGesture.direction=UISwipeGestureRecognizerDirectionRight;
        [rightGesture addTarget:self action:@selector(doRightAction)];
        [self.theImageView addGestureRecognizer:rightGesture];  
        
        UISwipeGestureRecognizer *leftGesture=[[UISwipeGestureRecognizer alloc] init];
        leftGesture.direction=UISwipeGestureRecognizerDirectionLeft;
        [leftGesture addTarget:self action:@selector(doLeftAction)];
        [self.theImageView addGestureRecognizer:leftGesture];  
        
        [slideShowTimeIntervalSlider setHidden:YES];        
    }
}

- (void) doRightAction {
    
    // Change Photo with Aimation
    CATransition *transition = [CATransition animation];
    transition.duration = 0.5;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    
    transition.type=kCATransitionPush; 
    
    transition.subtype=kCATransitionFromLeft;    
    
    self.nCurrentIndex++;
    
    if(nCurrentIndex>=[self.dataArray count])
        nCurrentIndex=0;
    
    [self configureView];
    
    [self.theImageView.layer addAnimation:transition forKey:nil];
}

- (void) doLeftAction {
    
    // Change Photo with Aimation
    CATransition *transition = [CATransition animation];
    transition.duration = 0.5;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    
    transition.type=kCATransitionPush; 
    
    transition.subtype=kCATransitionFromRight;       
    
    self.nCurrentIndex--;
    
    if(nCurrentIndex<0)
        nCurrentIndex=[self.dataArray count]-1;
    
    [self configureView];
    
    [self.theImageView.layer addAnimation:transition forKey:nil];    
}

- (void)viewDidUnload
{
    [self setTheScrollView:nil];
    [self setSlideShowTimeIntervalSlider:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView {
    
    return self.theImageView;
    
}

// Methods for Slideshow

- (void) handleTimer: (NSTimer *) timer
{
    if(bSlideShow==NO)
        return; // Do nothing when it is not slide show mode.
    
    if(CACurrentMediaTime()-lastPhotoUpdateTime>slideShowTimeInterval)
    {
        // Change Photo with Aimation
        
        CATransition *transition = [CATransition animation];
        transition.duration = 0.5;
        transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
        
        // Random to choose the method of animation
        switch (arc4random()%4) {
            case 0:
                transition.type=kCATransitionFade; 
                break;
            case 1:
                transition.type=kCATransitionMoveIn; 
                break;
            case 2:
                transition.type=kCATransitionPush; 
                break;
            case 3:
                transition.type=kCATransitionReveal; 
                break;                
                
            default:
                break;
        }
        
        // Random to choose the From
        switch (arc4random()%4) {
            case 0:
                transition.subtype=kCATransitionFromRight;
                break;
            case 1:
                transition.subtype=kCATransitionFromLeft;
                break;
            case 2:
                transition.subtype=kCATransitionFromTop;
                break;
            case 3:
                transition.subtype=kCATransitionFromBottom;
                break;                
                
            default:
                break;
        }        
        
        transition.delegate = self;
        
        nCurrentIndex++;
        
        if(nCurrentIndex>=[dataArray count])
        {
            nCurrentIndex=0;
        }
        
        //theScrollView.zoomScale=1; // reset the scale when show next photo        
        
        [self.theImageView setImage:[UIImage imageNamed:[dataArray objectAtIndex:nCurrentIndex]]];        
        
        [self.theImageView.layer addAnimation:transition forKey:nil];
        
        lastPhotoUpdateTime=CACurrentMediaTime();
        
    }
}

- (IBAction) sliderValueChanged:(UISlider*)sender {
    
    NSLog(@"Time Interval change to %.1f",sender.value);
    
    slideShowTimeInterval=sender.value;
    
}



@end





