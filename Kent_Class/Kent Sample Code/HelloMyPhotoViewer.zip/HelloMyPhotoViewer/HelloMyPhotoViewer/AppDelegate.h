//
//  AppDelegate.h
//  HelloMyPhotoViewer
//
//  Created by Liu Kent on 12/2/19.
//  Copyright (c) 2012年 SoftArt Laboratory. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
