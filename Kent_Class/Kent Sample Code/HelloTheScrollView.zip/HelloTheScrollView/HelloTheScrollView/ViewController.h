//
//  ViewController.h
//  HelloTheScrollView
//
//  Created by Liu Kent on 12/4/16.
//  Copyright (c) 2012年 SoftArt Laboratory. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UIScrollViewDelegate>
@property (weak, nonatomic) IBOutlet UIScrollView *theScrollView;

@end
