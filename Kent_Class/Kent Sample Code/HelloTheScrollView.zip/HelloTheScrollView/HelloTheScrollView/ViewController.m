//
//  ViewController.m
//  HelloTheScrollView
//
//  Created by Liu Kent on 12/4/16.
//  Copyright (c) 2012年 SoftArt Laboratory. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (nonatomic,strong) UIImageView *theImageView;
@end

@implementation ViewController
@synthesize theScrollView;
@synthesize theImageView;
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    UIImage *image=[UIImage imageNamed:@"cat.jpg"];
              
    self.theImageView=[[UIImageView alloc] initWithImage:image];
    
    self.theScrollView.contentSize=image.size;
    [self.theScrollView addSubview:self.theImageView];
    self.theScrollView.maximumZoomScale=3.0;
    self.theScrollView.minimumZoomScale=0.5;
    self.theScrollView.zoomScale=1.0;
    
    //self.theScrollView.pagingEnabled=YES;
}

- (void)viewDidUnload
{
    [self setTheScrollView:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (UIView*) viewForZoomingInScrollView:(UIScrollView *)scrollView {
    
    return self.theImageView;
    
}

- (void) scrollViewDidScroll:(UIScrollView *)scrollView {
    
    CGPoint offset=scrollView.contentOffset;
    
    NSLog(@"Content Offset: (%f,%f)",offset.x,offset.y);
    
}


@end
