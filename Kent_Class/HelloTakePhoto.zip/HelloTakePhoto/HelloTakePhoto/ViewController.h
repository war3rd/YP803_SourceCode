//
//  ViewController.h
//  HelloTakePhoto
//
//  Created by richman on 2014/10/23.
//  Copyright (c) 2014年 richman. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate>
@property (weak, nonatomic) IBOutlet UISegmentedControl *sourceTypeSegment;
@property (weak, nonatomic) IBOutlet UIImageView *resultImageView;
- (IBAction)GoButtonPressed:(id)sender;
@end

