//
//  ViewController.m
//  HelloTakePhoto
//
//  Created by richman on 2014/10/23.
//  Copyright (c) 2014年 richman. All rights reserved.
//

#import "ViewController.h"
#import <AssetsLibrary/AssetsLibrary.h>
@interface ViewController (){
    UIImagePickerController *imagePicker;
}
@end

@implementation ViewController
- (IBAction)GoButtonPressed:(id)sender{
    imagePicker=[UIImagePickerController new];
    imagePicker.delegate=self;
    imagePicker.sourceType=UIImagePickerControllerSourceTypePhotoLibrary;
    imagePicker.mediaTypes=@[@"public.image"];//@[@"public.image",@"public.movie"]
    [self presentViewController:imagePicker animated:YES completion:nil];
}

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    
    NSString *type=info[UIImagePickerControllerMediaType];
    if([type isEqualToString:@"public.image"]){
        UIImage *originalImage=info[UIImagePickerControllerOriginalImage];
        UIImage *modifiedImage=[self ResizingImage:originalImage:500:500];
        _resultImageView.image=modifiedImage;
        
        ALAssetsLibrary *library=[ALAssetsLibrary new];
        [library writeImageToSavedPhotosAlbum:modifiedImage.CGImage orientation:(ALAssetOrientation)modifiedImage.imageOrientation completionBlock:^(NSURL *assetURL, NSError *error) {
            UIAlertView *alertView=[[UIAlertView alloc]initWithTitle:nil message:@"Image Saved." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
            [alertView show];
        }];
        
        
    }else if([type isEqualToString:@"public.movie"]){
        NSLog(@"Movie at:%@",[info[UIImagePickerControllerMediaURL]path]);
    }
    [picker dismissViewControllerAnimated:YES completion:nil];
}
-(UIImage *)ResizingImage:(UIImage*)sourceImage:(float)newWidth:(float)newHeight{
    
    CGSize targetSize=CGSizeMake(newWidth, newHeight);
    UIGraphicsBeginImageContext(targetSize);
    [sourceImage drawInRect:CGRectMake(0, 0, targetSize.width, targetSize.height)];
    
    //Draw Frame
    UIImage *frame=[UIImage imageNamed:@"frame_01.png"];
    [frame drawInRect:CGRectMake(0, 0, targetSize.width, targetSize.height)];
    
    //Draw Text
    NSString *text=@"利賀！！";
    UIFont *font=[UIFont systemFontOfSize:60];
    NSDictionary *attributes=@{NSFontAttributeName:font,NSForegroundColorAttributeName:[UIColor redColor]};
    [text drawAtPoint:CGPointMake(50, 50) withAttributes:attributes];

                               
    
    
    UIImage *result=UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return result;
}


- (void)viewDidLoad {
    [super viewDidLoad];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
