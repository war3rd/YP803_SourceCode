//
//  DetailViewController.m
//  HelloPhotoViewer
//
//  Created by richman on 2014/10/7.
//  Copyright (c) 2014年 richman. All rights reserved.
//

#import "DetailViewController.h"

@interface DetailViewController ()

@end

@implementation DetailViewController

#pragma mark - Managing the detail item

- (void)setDetailItem:(id)newDetailItem {
    if (_detailItem != newDetailItem) {
        _detailItem = newDetailItem;
            
        // Update the view.
        [self configureView];
    }
}

- (void)configureView {
    // Update the user interface for the detail item.
    UIImage *targetImage=[UIImage imageNamed:_datas[_targetIndex]];
    _theImageView.image=targetImage;
    _theImageView.contentMode=UIViewContentModeScaleAspectFit;
    _theScrollView.contentSize=targetImage.size;
    _theScrollView.maximumZoomScale=5.0;
    float initScale=self.view.frame.size.width/targetImage.size.width;
    _theScrollView.minimumZoomScale=initScale;
    _theScrollView.zoomScale=initScale;
    
    
    
}
-(UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView{
    return _theImageView;
}
//-(UIView) viewForZoomingInScrollView:(UIScrollView *)scrollView{
//    return _theImageView;
//
//}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets=NO;
    // Do any additional setup after loading the view, typically from a nib.
    [self configureView];
    UISwipeGestureRecognizer *toLeft=[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(toLeft)];
    toLeft.direction=UISwipeGestureRecognizerDirectionLeft;
    [_theImageView addGestureRecognizer:toLeft];
    UISwipeGestureRecognizer *toRight=[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(toRight)];
    toRight.direction=UISwipeGestureRecognizerDirectionRight;
    [_theImageView addGestureRecognizer:toRight];
    _theImageView.userInteractionEnabled=YES;
    
}
-(void)toRight{
    _targetIndex--;
    if (_targetIndex<0) {
        _targetIndex=_datas.count-1;
        
    }
    [self configureView];
}
-(void)toLeft{
    _targetIndex++;
    if (_targetIndex>=_datas.count  ) {
        _targetIndex=0;
        
    }
    [self configureView];

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)playStopButtonPressed:(id)sender {
}
@end
