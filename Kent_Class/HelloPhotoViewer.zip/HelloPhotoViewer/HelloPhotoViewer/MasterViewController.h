//
//  MasterViewController.h
//  HelloPhotoViewer
//
//  Created by richman on 2014/10/7.
//  Copyright (c) 2014年 richman. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MasterViewController : UITableViewController


@end

