//
//  DetailViewController.h
//  HelloPhotoViewer
//
//  Created by richman on 2014/10/7.
//  Copyright (c) 2014年 richman. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController<UIScrollViewDelegate>

@property (strong, nonatomic) id detailItem;
@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel;
@property (strong,nonatomic)NSMutableArray *datas;
@property (assign,nonatomic)NSInteger  targetIndex;
@property (strong, nonatomic) IBOutlet UIScrollView *theScrollView;
@property (strong, nonatomic) IBOutlet UIImageView *theImageView;
- (IBAction)playStopButtonPressed:(id)sender;
@end

